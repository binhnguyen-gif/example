<table>
    <thead>
        <tr style="background-color: #ccc">
            <th></th>
            <th>Title</th>
            <th>Description</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $workflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $workflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($index); ?></td>
            <td><?php echo e($workflow->title); ?></td>
            <td><?php echo e($workflow->description); ?></td>
            <td><?php echo e($workflow->start_date); ?></td>
            <td><?php echo e($workflow->end_date); ?></td>
            <td><?php echo e(($workflow->status == 1) ? 'Active' : 'Inactive'); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\php-training\resources\views/exports/workflows.blade.php ENDPATH**/ ?>