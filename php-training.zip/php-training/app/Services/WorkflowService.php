<?php

namespace App\Services;

use App\Repositories\Workflow\WorkflowRepository;

class WorkflowService
{

    protected $workflowRepository;

    public function __construct(WorkflowRepository $workflowRepository)
    {
        $this->workflowRepository = $workflowRepository;
    }


}
