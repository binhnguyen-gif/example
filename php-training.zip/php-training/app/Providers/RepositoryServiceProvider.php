<?php

namespace App\Providers;

use App\Repositories\Workflow\WorkflowRepository;
use App\Repositories\Workflow\WorkflowRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->bind(WorkflowRepositoryInterface::class, WorkflowRepository::class);
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
