<?php

namespace App\Exports;

use App\Models\Workflow;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class WorkflowsExport implements FromView
{
    public function view(): View
    {
        return view('exports.workflows', [
            'workflows' => Workflow::all()
        ]);
    }
}
