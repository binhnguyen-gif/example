<?php

namespace App\Repositories\Workflow;

use App\Repositories\RepositoryInterface;

interface WorkflowRepositoryInterface extends RepositoryInterface
{
    public function search($request);
}
