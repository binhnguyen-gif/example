<?php

namespace App\Repositories\Workflow;

use App\Repositories\BaseRepository;

class WorkflowRepository extends BaseRepository implements WorkflowRepositoryInterface
{
    public function getModel()
    {
        return \App\Models\Workflow::class;
    }

    public function search($request)
    {
        $query = $this->model->query()->when($request->get('search'), function ($query, $search) {
            $search = strtolower(trim($search));
            return $query->whereRaw('LOWER(title) LIKE ?', ["%$search%"]);
        })->when($request->get('sort'), function ($query, $sortBy) {
            return $query->orderBy($sortBy['key'], $sortBy['order']);
        })->whereUser();

        return $query->paginate($request->get('limit', 10));
    }
}





