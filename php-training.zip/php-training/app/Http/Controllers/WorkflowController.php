<?php

namespace App\Http\Controllers;

use App\Http\Requests\Workflow\CreateRequest;
use App\Models\Workflow;
use App\Repositories\Workflow\WorkflowRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use App\Exports\WorkflowsExport;
use Maatwebsite\Excel\Facades\Excel;

class WorkflowController extends Controller
{
    protected $workflowRepo;

    public function __construct(WorkflowRepositoryInterface $workflowRepo)
    {
        $this->workflowRepo = $workflowRepo;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $data = $this->workflowRepo->search($request);
//dd($data);
        return Inertia::render('Workflow/Index', [
            'data' => $data
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('Workflow/Create');
    }

    public function store(CreateRequest $request)
    {

        $data = $request->validated();
        $data['user_id'] = Auth::user()->id;
        $workflow = $this->workflowRepo->create($data);
        $message = sprintf('Successfully created %s', $workflow->title);

        return redirect()->back()->with('success', $message);
    }

    public function edit(Workflow $workflow)
    {
        return Inertia::render('Workflow/Edit', [
            'workflow' => $workflow
        ]);
    }

    public function update(Workflow $workflow, CreateRequest $request)
    {
        $data = $request->validated();
        $this->workflowRepo->update($workflow->id, $data);
        $message = sprintf('Successfully updated %s', $workflow->title);

        return redirect()->back()->with('success', $message);
    }

    public function destroy(Workflow $workflow)
    {
        $this->workflowRepo->delete($workflow->id);
        $message = sprintf('Successfully deleted %s', $workflow->title);

        return redirect()->back()->with('success', $message);
    }

    public function import(Request $request)
    {
        // Excel::import(new WorkflowsImport, 'users.xlsx');

        // return redirect('/')->with('success', 'All good!');
    }

    public function export()
    {
        return Excel::download(new WorkflowsExport, 'workflows.xlsx');
    }
}
