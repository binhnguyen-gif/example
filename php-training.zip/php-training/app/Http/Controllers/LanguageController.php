<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Inertia\Inertia;

class LanguageController extends Controller
{
    public function index(Request $request) {
        $locale = $request->input('lang');

        if(in_array($locale, config('app.locales'))) {
            App::setLocale($locale);
        }

        return response()->json(['locale' => App::getLocale()], 200);
    }
}
