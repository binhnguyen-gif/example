#!/usr/bin/env bash

/usr/bin/php /var/www/html/artisan migrate --force --no-ansi -q
