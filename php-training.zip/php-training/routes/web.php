<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PeopleController;
use App\Http\Controllers\WorkflowController;
use App\Http\Controllers\LanguageController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::resource('/people', PeopleController::class)->except(['show']);
Route::resource('/workflow', WorkflowController::class)->except(['show']);
Route::get('workflow/export', [WorkflowController::class, 'export'])->name('workflow.export');
Route::get('workflow/import', [WorkflowController::class, 'import'])->name('workflow.export');
Route::get('locale/{lang}', [LanguageController::class, 'index'])->name('locale.index');

require __DIR__.'/auth.php';
