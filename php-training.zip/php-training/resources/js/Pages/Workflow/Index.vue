<template>
  <Head title="Workflow" />
  <AuthenticatedLayout>
    <div class="mb-5">
      <h5 class="text-h5 font-weight-bold">Workflow</h5>
      <Breadcrumbs :items="breadcrumbs" class="pa-0 mt-1" />
    </div>
    <v-card class="pa-4">
      <div class="d-flex flex-wrap align-center">
        <v-text-field
          v-model="search"
          label="Search"
          variant="underlined"
          prepend-inner-icon="mdi-magnify"
          hide-details
          clearable
          single-line
        />
        <v-spacer />
        <Link href="/workflow/create" as="div">
          <v-btn color="primary">{{ $t('workflow.create') }}</v-btn>
        </Link>
        <a :href="importUrl" class="v-btn ml-2 px-2 py-2 text-white bg-primary v-btn--elevated">{{
          $t('workflow.import')
        }}</a>
        <a :href="exportUrl" class="v-btn ml-2 px-2 py-2 text-white bg-primary v-btn--elevated">
          {{ $t('workflow.export') }}
        </a>
      </div>
      <v-data-table-server
        :items="initData"
        :items-length="props.data.total"
        :headers="headers"
        :search="search"
        class="elevation-0"
        :loading="isLoadingTable"
        @update:options="loadItems"
      >
        <template #[`item.action`]="{ item }">
          <Link :href="`/workflow/${item.id}/edit`" as="button">
            <v-icon color="warning" icon="mdi-pencil" size="small" />
          </Link>
          <v-icon class="ml-2" color="error" icon="mdi-delete" size="small" @click="deleteItem(item)" />
        </template>
      </v-data-table-server>
    </v-card>
    <v-row justify="center">
      <v-dialog v-model="deleteDialog" persistent width="auto">
        <v-card>
          <v-card-text>{{ $t('workflow.notice') }}</v-card-text>
          <v-card-actions>
            <v-spacer />
            <v-btn color="error" text @click="closeDialog">{{ $t('workflow.cancel') }}</v-btn>
            <v-btn color="primary" :loading="isLoading" text @click="submitDelete">{{ $t('workflow.delete') }}</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-row>
  </AuthenticatedLayout>
</template>

<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'
import Breadcrumbs from '@/Components/Breadcrumbs.vue'
import { Head, Link, router } from '@inertiajs/vue3'

// const message = usePage().props.flash.message
import { ref, onMounted, computed } from 'vue'

const props = defineProps({
  data: Object,
})

const initData = ref([])

onMounted(() => {
  initData.value = props.data.data
})

const breadcrumbs = ref([
  {
    title: 'Dashboard',
    disabled: false,
    href: '/dashboard',
  },
  {
    title: 'Workflow',
    disabled: true,
  },
])

const headers = ref([
  { title: `title`, key: 'title' },
  { title: `description`, key: 'description' },
  { title: `start_date`, key: 'start_date' },
  { title: `end_date`, key: 'end_date' },
  { title: `status`, key: 'status' },
  { title: `action`, key: 'action', sortable: false },
])

const isLoadingTable = ref(false)
const search = ref(null)
const deleteDialog = ref(false)
const isLoading = ref(false)
const deleteId = ref(null)

const closeDialog = () => {
  deleteDialog.value = false
}

const exportUrl = computed(() => {
  return `workflow/export`
})

const importUrl = computed(() => {
  return `workflow/import`
})

function loadItems({ page, itemsPerPage, sortBy, search }) {
  isLoadingTable.value = true
  let params = {
    page: page,
    limit: itemsPerPage,
    sort: sortBy[0],
  }
  if (search) {
    params.search = search
  }
  router.get('workflow', params, {
    preserveState: true,
    preserveScroll: true,
    onSuccess: (res) => {
      console.log(res.props.data.data)
      initData.value = res.props.data.data
      isLoadingTable.value = false
    },
  })
}

function deleteItem(item) {
  deleteId.value = item.id
  deleteDialog.value = true
}

function submitDelete() {
  isLoading.value = true
  router.delete(`/workflow/${deleteId.value}`, {
    preserveState: true,
    preserveScroll: true,
    onSuccess: (res) => {
      console.log(res.props.data.data)
      initData.value = res.props.data.data
      isLoading.value = false
      deleteDialog.value = false
    },
  })
}
</script>
