<template>
  <Head title="Edit workflow" />
  <AuthenticatedLayout>
    <div class="mb-5">
      <h5 class="text-h5 font-weight-bold">{{ $t('workflow.edit') }}</h5>
      <Breadcrumbs :items="breadcrumbs" class="pa-0 mt-1" />
    </div>
    <v-card>
      <v-form @submit.prevent="submit">
        <v-card-text>
          <v-row>
            <v-col cols="12" sm="12" md="6">
              <v-text-field
                v-model="form.title"
                :label="$t('workflow.title')"
                variant="underlined"
                :error-messages="form.errors.title"
              />
            </v-col>
            <v-col cols="12" sm="12" md="6">
              <v-text-field
                v-model="form.start_date"
                :label="$t('workflow.start_date')"
                variant="underlined"
                type="date"
                :error-messages="form.errors.start_date"
              />
            </v-col>
            <v-col cols="12" sm="12" md="6">
              <v-text-field
                v-model="form.end_date"
                :label="$t('workflow.end_date')"
                variant="underlined"
                type="date"
                :error-messages="form.errors.end_date"
              />
            </v-col>
            <v-col cols="12" sm="12" md="6">
              <v-select
                v-model="form.status"
                :items="initStatus"
                item-title="text"
                item-value="value"
                :label="$t('workflow.status')"
                variant="underlined"
                :error-messages="form.errors.status"
              />
            </v-col>
            <v-col cols="12" sm="12">
              <v-textarea
                v-model="form.description"
                :label="$t('workflow.description')"
                variant="underlined"
                :error-messages="form.errors.description"
              />
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <Link href="/workflow" as="div">
            <v-btn text>{{ $t('workflow.cancel') }}</v-btn>
          </Link>
          <v-btn type="submit" color="primary">{{ $t('workflow.save') }}</v-btn>
        </v-card-actions>
      </v-form>
    </v-card>
  </AuthenticatedLayout>
</template>

<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'
import Breadcrumbs from '@/Components/Breadcrumbs.vue'
import { Head, Link, useForm, router, usePage } from '@inertiajs/vue3'
import { ref, onMounted } from 'vue'

const props = defineProps({
  workflow: {
    type: Object,
    required: true,
  },
})

const page = usePage()

// const data = page.props.data

onMounted(() => {
  console.log(page)
})

const form = useForm({
  title: props.workflow.title,
  description: props.workflow.description,
  start_date: props.workflow.start_date,
  end_date: props.workflow.end_date,
  status: props.workflow.status,
})

const initStatus = ref([
  { text: 'Active', value: 1 },
  { text: 'Inactive', value: 0 },
])

const submit = () => {
  form.patch('/workflow/' + props.workflow.id, {
    onSuccess: () => {
      router.visit('/workflow')
    },
  })
  // form.patch(route('workflow.post', { id: props.workflow.id }), {
  //   onSuccess: (response) => {
  //     router.visit('/workflow')
  //   },
  // })
}

const breadcrumbs = ref([
  {
    title: 'Dashboard',
    disabled: false,
    href: '/dashboard',
  },
  {
    title: 'Workflow',
    disabled: false,
    href: '/workflow',
  },
  {
    title: 'Edit',
    disabled: true,
  },
])
</script>
