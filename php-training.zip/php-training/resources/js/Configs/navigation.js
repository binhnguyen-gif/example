export default {
  items: [
    {
      title: 'Dashboard',
      icon: 'mdi-view-dashboard',
      to: '/dashboard',
    },
    {
      title: 'People',
      icon: 'mdi-account-group',
      to: '/people',
    },
    {
      title: 'Workflow',
      icon: 'mdi-sitemap',
      to: '/workflow',
    },
  ],
}
