<!-- <template>
  <div>
    <v-dialog v-model="deleteDialog" persistent width="auto">
      <v-card>
        <v-card-text>{{ $t('workflow.notice') }}</v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn color="error" text @click="closeDialog">{{ $t('workflow.cancel') }}</v-btn>
          <v-btn color="primary" :loading="isLoading" text @click="submitDelete">{{ $t('workflow.delete') }}</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template> -->
