<script setup>
import { Link } from '@inertiajs/vue3'
import navigation from '@/Configs/navigation'
import { ref, watch } from 'vue'

const locale = ref('en')
const initLocale = ref([
  { text: 'English', value: 'en' },
  { text: 'Tiếng Việt', value: 'vi' },
])

watch(locale, (current) => {
  var currentUrl = window.location.origin
  fetch(currentUrl + `/locale/${current}`).then((response) => response.json())
  this.forceUpdate()
})
</script>

<template>
  <v-list nav>
    <!-- List Menu -->
    <Link v-for="(item, key) in navigation.items" :key="key" :href="item.to" as="div">
      <v-list-item
        :prepend-icon="item.icon"
        :title="item.title"
        :exact="item.exact"
        link
        :class="{ 'v-list-item--active': $page.url.startsWith(item.to) }"
      />
    </Link>
    <Link href="/locale" method="get" as="div">
      <v-select
        v-model="locale"
        :items="initLocale"
        item-title="text"
        item-value="value"
        label="Language"
        variant="underlined"
      />
    </Link>
    <!-- Log Out -->
    <Link href="/logout" method="post" as="div">
      <v-list-item prepend-icon="mdi-exit-to-app" title="Log Out" link />
    </Link>
  </v-list>
</template>
