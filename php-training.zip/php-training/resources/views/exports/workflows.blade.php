<table>
    <thead>
        <tr style="background-color: #ccc">
            <th></th>
            <th>Title</th>
            <th>Description</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    @foreach($workflows as $index => $workflow)
        <tr>
            <td>{{ $index }}</td>
            <td>{{ $workflow->title }}</td>
            <td>{{ $workflow->description }}</td>
            <td>{{ $workflow->start_date }}</td>
            <td>{{ $workflow->end_date }}</td>
            <td>{{ ($workflow->status == 1) ? 'Active' : 'Inactive' }}</td>
        </tr>
    @endforeach
    </tbody>
</table>
