<?php

namespace Database\Seeders;

use Database\Factories\WorkflowFactory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class WorkflowSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        WorkflowFactory::new()->count(100)->create();
    }
}
