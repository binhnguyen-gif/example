<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Workflow>
 */
class WorkflowFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $start = $this->faker->date($format = 'Y-m-d', $max = 'now');
        return [
            'title' => $this->faker->sentence($nbWords = 6, $variableNbWords = true),
            'user_id' => User::query()->first()->id,
            'description' => $this->faker->realText($maxNbChars = 200, $indexSize = 2),
            'start_date' => $start,
            'end_date' => $start,
            'status' => $this->faker->boolean(),
        ];
    }
}
